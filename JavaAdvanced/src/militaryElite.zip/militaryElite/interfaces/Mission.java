package militaryElite.interfaces;

public interface Mission {
    void completeMission();
}