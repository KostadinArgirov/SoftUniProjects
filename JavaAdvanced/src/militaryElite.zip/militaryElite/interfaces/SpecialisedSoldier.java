package militaryElite.interfaces;

import militaryElite.enums.Corps;

public interface SpecialisedSoldier {
    Corps getCorps();
}