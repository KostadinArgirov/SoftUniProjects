package militaryElite.interfaces;

public interface Repair {
}